package cn.edu.sicnu.jz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import cn.edu.sicnu.jz.adapter.MainPagerAdapter;
import cn.edu.sicnu.jz.frag_first.BBFragment;
import cn.edu.sicnu.jz.frag_first.FirstFragment;
import cn.edu.sicnu.jz.frag_first.JZFragment;

public class MainActivity extends AppCompatActivity {
    TabLayout tabLayout1;
    ViewPager viewPager1;
//头布局控件
    View headerView;
    Fragment firstFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView mBottomNV = (BottomNavigationView) findViewById(R.id.main_menu_bottom);
        mBottomNV.setItemIconTintList(null);
//        setmainFragment();
        firstFragment=new FirstFragment();

        //头布局
        addLVHeaderView();
        //
        tabLayout1 = findViewById(R.id.main_tabs);
        viewPager1 = findViewById(R.id.main_vp);
        initPager();
    }

//    private void setmainFragment() {
//        getSupportFragmentManager().beginTransaction()
//                .replace(R.id.frameLayout,new FirstFragment())
//                .commit();
//    }
    private void initPager() {
        List<Fragment> fragmentList = new ArrayList<>();
        JZFragment outFrag = new JZFragment();
        BBFragment inFrag = new BBFragment();
        fragmentList.add(outFrag);
        fragmentList.add(inFrag);


        //适配器
        MainPagerAdapter pagerAdapter=new MainPagerAdapter(getSupportFragmentManager(),fragmentList);

        //设置适配器
        viewPager1.setAdapter(pagerAdapter);
        //taplayout he viewpager关联
        tabLayout1.setupWithViewPager(viewPager1);

    }


    private void addLVHeaderView() {
        headerView = getLayoutInflater().inflate(R.layout.item_mainlv_top, null);

    }

    public void onClick(View view) {
        switch (view.getId()){
            case R.id.main_iv_search:
                Intent it1=new Intent(this,SearchActivity.class);
                startActivity(it1);
                break;
            case R.id.main_btn_edit:
                Intent it2=new Intent(this,RecordActivity.class);
                startActivity(it2);
                break;

        }
    }
}