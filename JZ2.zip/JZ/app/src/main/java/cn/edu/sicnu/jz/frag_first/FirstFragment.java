package cn.edu.sicnu.jz.frag_first;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import cn.edu.sicnu.jz.R;
import cn.edu.sicnu.jz.SearchActivity;
import cn.edu.sicnu.jz.adapter.MainPagerAdapter;


public class FirstFragment extends Fragment {

    TabLayout tabLayout1;
    ViewPager viewPager1;
    //头布局控件
    View headerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //头布局
        addLVHeaderView();
        //
        tabLayout1 = view.findViewById(R.id.main_tabs);
        viewPager1 =view.findViewById(R.id.main_vp);

        initPager();
    }



    private void initPager() {
        List<Fragment> fragmentList = new ArrayList<>();
        JZFragment outFrag = new JZFragment();
        BBFragment inFrag = new BBFragment();
        fragmentList.add(outFrag);
        fragmentList.add(inFrag);


        //适配器
        MainPagerAdapter pagerAdapter=new MainPagerAdapter(getFragmentManager(),fragmentList);

        //设置适配器
        viewPager1.setAdapter(pagerAdapter);
        //taplayout he viewpager关联
        tabLayout1.setupWithViewPager(viewPager1);

    }


    private void addLVHeaderView() {
        headerView = getLayoutInflater().inflate(R.layout.item_mainlv_top, null);

    }


    public void onClick(View view) {
        Log.d("onClick","ok");
        switch (view.getId()){
            case R.id.main_iv_search:
                Intent it1=new Intent(getContext(), SearchActivity.class);
                startActivity(it1);
                break;


        }
    }
}